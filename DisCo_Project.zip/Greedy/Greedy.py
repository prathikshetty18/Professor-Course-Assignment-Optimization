import json
import random
import time
import os
import shutil
from tabulate import tabulate


class Distwithallconstraints:
    def __init__(self, noofsolns):
        self.read_data()
        self.delete_remake_folder()
        self.distribution(noofsolns)

    def read_data(self):
        with open("RandomInput.json", "r") as input_dict:
            data = json.load(input_dict)
        self.subjects = data["Subjects"]
        self.subject_names = [element for element in self.subjects for i in range(2)]

        self.profs = data["Professors"]
        prof_names = self.profs.keys()
        self.prof_names = [element for element in prof_names for i in range(self.profs[element]["X"])]
        for prof in self.profs.keys():
            
            self.profs[prof]["TotalPriority"] = self.profs[prof]["PL-FDCDC"] + self.profs[prof]["PL-HDCDC"] + \
                                                self.profs[prof]["PL-FDE"] + self.profs[prof]["PL-HDE"]

    def delete_remake_folder(self):
        try:
            shutil.rmtree("GreedyOutputs")
        except:
            os.makedirs("GreedyOutputs")
        try:
            os.makedirs("GreedyOutputs")
        except:
            print()
        

    def shuffle_list(self, original_list):
        shuffled_list = original_list.copy()
        random.shuffle(shuffled_list)
        return shuffled_list

    def allowed_fun(self, profnamelist, subject, subjectremaininglist, index):
        res = True
        subjects_copy = subjectremaininglist.copy()
        subjects_copy.remove(subject)
        index = index + 1

        for p in profnamelist[index::]:
            temp = 0
            for pref in self.profs[p]["TotalPriority"]:
                if pref in subjects_copy:
                    temp = 1
            if temp == 0:
                res = False

        return res

    def distribution(self, noofsolns):
        allsolns = set()
        start = time.perf_counter()
        first_n_permutations = [self.shuffle_list(self.prof_names) for _ in range(noofsolns)]
        first_n_permutations_list = list(first_n_permutations)
        ass_count = 0
        for current_prof_names in first_n_permutations_list:
            subjects_remaining_list = self.subject_names.copy()
            prof_assign = {}
            temp1 = 0
            temp2 = 0
            for i in range(1, len(current_prof_names) + 1):
                key = current_prof_names[temp1] + "_" + str(temp1)
                prof_assign[key] = None
                temp1 = temp1 + 1
            for p in current_prof_names:
                check = 0
                assignchk1, assignchk2, assignchk3 = 0, 0, 0
                for pref in self.profs[p]["PL-FDCDC"]:
                    if pref in subjects_remaining_list:
                        if prof_assign[p + "_" + str(temp2)] is None:
                            if self.allowed_fun(current_prof_names, pref, subjects_remaining_list, temp2):
                                prof_assign[p + "_" + str(temp2)] = pref
                                subjects_remaining_list.remove(pref)
                                temp2 = temp2 + 1
                                check = 1
                                assignchk1 = 1
                                break
                if (assignchk1 == 0):
                    for pref in self.profs[p]["PL-HDCDC"]:
                        if pref in subjects_remaining_list:
                            if prof_assign[p + "_" + str(temp2)] is None:
                                if self.allowed_fun(current_prof_names, pref, subjects_remaining_list, temp2):
                                    prof_assign[p + "_" + str(temp2)] = pref
                                    subjects_remaining_list.remove(pref)
                                    temp2 = temp2 + 1
                                    check = 1
                                    assignchk2 = 1
                                    break
                if (assignchk1 == 0 and assignchk2 == 0):
                    for pref in self.profs[p]["PL-FDE"]:
                        if pref in subjects_remaining_list:
                            if prof_assign[p + "_" + str(temp2)] is None:
                                if self.allowed_fun(current_prof_names, pref, subjects_remaining_list, temp2):
                                    prof_assign[p + "_" + str(temp2)] = pref
                                    subjects_remaining_list.remove(pref)
                                    temp2 = temp2 + 1
                                    check = 1
                                    assignchk3 = 1
                                    break
                if (assignchk1 == 0 and assignchk2 == 0 and assignchk3 == 0):
                    for pref in self.profs[p]["PL-HDE"]:
                        if pref in subjects_remaining_list:
                            if prof_assign[p + "_" + str(temp2)] is None:
                                if self.allowed_fun(current_prof_names, pref, subjects_remaining_list, temp2):
                                    prof_assign[p + "_" + str(temp2)] = pref
                                    subjects_remaining_list.remove(pref)
                                    temp2 = temp2 + 1
                                    check = 1
                                    break
                if (check == 0):
                    temp2 = temp2 + 1
            finalchk = True
            for i in subjects_remaining_list:
                """TO ENSURE 0.5 SUBJECT DOESNT GET ASSIGNED AND ALL CDCS GET ASSIGNED IF POSSIBLE"""
                if "CDC" in i:
                    finalchk = False
                    break
                if (subjects_remaining_list.count(str(i))%2 == 1):
                    finalchk = False
                    break
            if(finalchk):
                if None not in prof_assign.values():
                    solnmatrix = []
                    for key, value in prof_assign.items():
                        solnmatrix.append([str(key.split("_")[0]),value])
                    finalsoln = sorted(solnmatrix, key=lambda x: int(x[0][4:]))
                    table = tabulate(finalsoln, headers=["Professor", "Subject"], tablefmt="grid")
                    with open("GreedyOutputs/Output"+str(ass_count+1), 'w') as file:
                        file.write(table)
                if None not in prof_assign.values():
                    ass_count += 1
                print("\n")

        print(ass_count)
        end = time.perf_counter()
        print(end - start)
        
        if(ass_count) == 0:
            print("NO SOLUTIONS TO GIVEN INPUT PLEASE PROVIDE DIFFERENT ONE")


obj1 = Distwithallconstraints(10000)