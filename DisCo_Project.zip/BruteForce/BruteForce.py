import json
from itertools import permutations
import numpy as np
from tabulate import tabulate

class SubjectDistribution:
    def read_file(self):
        with open("BruteForceInput.json", 'r') as file:
            self.data = json.load(file)

    def __init__(self):
        self.read_file()
        self.subjects = self.data["Subjects"]
        self.usablesubjects = 2*self.subjects
        self.profs = self.data["Professors"]
        self.usableproflist=[keys for keys,values in self.profs.items() for _ in range(values["X"])]

    def happiness_value(self,subjectno,profno):
        list = self.profs[profno]["Prioritylist"]
        happinessvalue = len(self.subjects)
        try:
            happinessvalue -= list.index(subjectno)
        except ValueError:
            happinessvalue = 0
        return happinessvalue

    def find_all_instances(self,matrix, variable):
        instances = []

        for i, row in enumerate(matrix):
            for j, element in enumerate(row):
                if element == variable:
                    instances.append((i, j))

        return instances

    def max_happiness(self):
        unique_permutations = set(permutations(self.usablesubjects))
        self.rows = list(unique_permutations)
        unique_permutations2 = set(permutations(self.usableproflist))
        self.columns = list(unique_permutations2)
        happiness = np.zeros((len(self.rows),len(self.columns)))
        for row in range(len(self.rows)):
            for col in range(len(self.columns)):
                element = 0
                for subject in range(len(self.rows[row])):
                    element += self.happiness_value(self.rows[row][subject],self.columns[col][subject])
                happiness[row][col] = element
        table = tabulate(happiness, tablefmt="fancy_grid")
        print(table)
        maximum = max(happiness.flatten())
        print(maximum)
        self.idealsoln = self.find_all_instances(happiness,maximum)
        print(self.idealsoln)


    def printsolutions(self):
        for i in self.idealsoln:
            print("__________________________")
            print(self.rows[i[0]])
            print(self.columns[i[1]])
            print("__________________________")
        print(len(self.idealsoln))

obj1 = SubjectDistribution()
obj1.max_happiness()
obj1.printsolutions()

