This is the README file for the Greedy Algorithm Method

Components:
1.GenerateDataSem1.py
    Used to generate RandomInput.json which is used to feed Data to the Main Code


2.RandomInput.json
    This is a JSON(JavaScript Object Notation File) that serves as input for the Greedy.py Program
    It consists of all Sem1 Subjects and Professors enough to cover all CDCs but may or may not be enoguh to cover all Electives (Here the subjects are divided into 4 types and all Professors give their preference lists for each type)


3.GreedyOutputs Folder
    This is the output folder for Greedy.py program where every solution to the prof-course assignment problem has its own output text file    


4.Greedy.py
    The code starts by importing the necessary libraries:
    json: For reading JSON data from a file
    random: For shuffling the order of professors to get multiple solutions
    time: For calculatin the time to run the program
    os: To create a new GreedyOutputs Folder every time the code is executed
    shutil: To delete the previous GreedyOutputs Folder every time the code is executed
    tabulate: For creating tabular data representations

Procedure:
    The Code starts by reading necessary data and storing it in an orderly fashion.
    The it deletes the previous GreedyOutputs folder and creates a new GreedyOutputs to store the new output text files.
    It shuffles the order of prof list to a new permutation. 
    It starts by assigning CDC to all the profs in order according to their preference order.
    Once all FDCDC and HDCDC's are assigned it then starts allocating FDELE and HDELE courses to profs wherever possible.
    It makes checks for the contraints ensuring that each prof gets the assigned number of credits, no CDC is unassigned and that no elective gets half assigned.
    If all these checks are cleared and constraints are satisfied then we get a feasible solution to the assignment problem. The feasible solutions are filetered out.
    Output in the form of a table is written inside GreedyOutputs Folder as output text files.
    This process is repeated 10,000 times to generate multiple solutions to the assignment problem.

Merits of Method:
    This method gives us MULTIPLE SUBOPTIMAL solutions to the problem.
    Has MUCH BETTER Time Complexity(O(n^4)) compared to BruteForce method.

Demerits of Method:
    Though it starts printing multiple solutions immediately it takes around 2 mins to print all the solutions.
    It requires a lot of iterations in the code to filter out actual solutions(10000 iterations in our case)

How to Run:
    Place GenerateDataSem1.py, RandomInput.json and Greedy.py in the same Directory
    Run GenerateDataSem1.py then run Greedy.py
    Output will be available in the GreedyOutputs folder.

