import pulp as pl
import json
from tabulate import tabulate


class Distribution_with_LP:

    def read_file(self):
        with open("RandomInput.json", 'r') as file:
            self.data = json.load(file)

    def happiness_fun(self, prof, subject):
        happiness = 0
        if (str(subject)[0:3] == "FDC"):
            try:
                happiness = len(self.usablesubjects) - self.profs[prof]["PL-FDCDC"].index(subject)
            except:
                happiness = 0
        elif (str(subject)[0:3] == "FDE"):
            try:
                happiness = len(self.usablesubjects) - self.profs[prof]["PL-FDE"].index(subject)
            except:
                happiness = 0
        elif (str(subject)[0:3] == "HDC"):
            try:
                happiness = len(self.usablesubjects) - self.profs[prof]["PL-HDCDC"].index(subject)
            except:
                happiness = 0
        elif (str(subject)[0:3] == "HDE"):
            try:
                happiness = len(self.usablesubjects) - self.profs[prof]["PL-HDE"].index(subject)
            except:
                happiness = 0
        return happiness

    def __init__(self):
        self.read_file()
        self.subjects = self.data["Subjects"]
        self.usablesubjects = 2 * self.subjects #cause every subject can be split into o.5 among 2 teachers
        self.profs = self.data["Professors"]
        self.usableproflist = [keys for keys, values in self.profs.items() for _ in range(values["X"])]
        self.FDCDC_Subjects = []
        self.HDCDC_Subjects = []
        self.FDE_Subjects = []
        self.HDE_Subjects = []
        for subject in self.subjects:
            temp = subject.split("-")
            if ("FDCDC" in temp[0]):
                self.FDCDC_Subjects.append(subject)
                self.FDCDC_Subjects.append(subject)
            elif ("HDCDC" in temp[0]):
                self.HDCDC_Subjects.append(subject)
                self.HDCDC_Subjects.append(subject)
            elif ("FDE" in temp[0]):
                self.FDE_Subjects.append(subject)
                self.FDE_Subjects.append(subject)
            elif ("HDE" in temp[0]):
                self.HDE_Subjects.append(subject)
                self.HDE_Subjects.append(subject)
        self.allsubs = [self.FDCDC_Subjects,self.HDCDC_Subjects,self.FDE_Subjects,self.HDE_Subjects]
        self.distrinbution()

    def distrinbution(self):
        lp = pl.LpProblem("Subject Distribution",pl.LpMaximize)
        FDCDCvars = []
        HDCDCvars = []
        FDEvars = []
        HDEvars = []
        varno = 0

        # setting all variables
        for i in range(len(self.usableproflist)):
            for j in range(len(self.FDCDC_Subjects)):
                tempname = str(self.usableproflist[i]) + "_" + str(self.FDCDC_Subjects[j]) + "_" + str(varno)
                FDCDCvars.append(pl.LpVariable(name=tempname, cat="Binary"))
                varno += 1
            for j in range(len(self.HDCDC_Subjects)):
                tempname = str(self.usableproflist[i]) + "_" + str(self.HDCDC_Subjects[j]) + "_" + str(varno)
                HDCDCvars.append(pl.LpVariable(name=tempname, cat="Binary"))
                varno += 1
            for j in range(len(self.FDE_Subjects)):
                tempname = str(self.usableproflist[i]) + "_" + str(self.FDE_Subjects[j]) + "_" + str(varno)
                FDEvars.append(pl.LpVariable(name=tempname, cat="Binary"))
                varno += 1
            for j in range(len(self.HDE_Subjects)):
                tempname = str(self.usableproflist[i]) + "_" + str(self.HDE_Subjects[j]) + "_" + str(varno)
                HDEvars.append(pl.LpVariable(name=tempname, cat="Binary"))
                varno += 1
        allvars = [FDCDCvars,HDCDCvars,FDEvars,HDEvars]

        # objective function
        for i in range(4):
            for j in range(len(allvars[i])):
                tempprof = str(allvars[i][j].name.split("_")[0])
                tempsub = str(allvars[i][j].name.split("_")[1]) + "-" + str(allvars[i][j].name.split("_")[2]) + "-" + str(allvars[i][j].name.split("_")[3])
                lp += lp.objective + allvars[i][j] * self.happiness_fun(tempprof,tempsub)
        print(lp.objective)
        print("_______________________________________________________________________")
        print(allvars)

        # constraints
        iterable1 = range(0, len(allvars[0]), len(self.allsubs[0]))
        iterable2 = range(0, len(allvars[1]), len(self.allsubs[1]))
        iterable3 = range(0, len(allvars[2]), len(self.allsubs[2]))
        iterable4 = range(0, len(allvars[3]), len(self.allsubs[3]))
        for i, j, k, l in zip(iterable1, iterable2, iterable3, iterable4):
            lp += sum(allvars[0][i:i + len(self.allsubs[0])]) + sum(allvars[1][j:j + len(self.allsubs[1])])+ sum(allvars[2][k:k + len(self.allsubs[2])]) + sum(allvars[3][l:l + len(self.allsubs[3])])<= 1  # to ensure every prof doesn't take more than their max subjects
        print("_______________________________________________________________________")
        for j in range(2):
            for i in range(len(self.allsubs[j])):
                templist = allvars[j][i::len(self.allsubs[j])]  # to ensure that each subject doesn't have extra profs
                print(templist)
                lp += sum(templist) == 1
        print("_______________________________________________________________________")
        for j in range(2,4):
            for i in range(len(self.allsubs[j])):
                templist = allvars[j][i::len(self.allsubs[j])]  # to ensure that each subject doesn't have extra profs
                print(templist)
                lp += sum(templist) <= 1
                if(i < len(self.allsubs[j])-1):
                    templist2 = allvars[j][i+1::len(self.allsubs[j])]
                    lp += sum(templist) - sum(templist2) == 0
                    print(templist2,"\n")


        status = lp.solve()
        print(status)
        print()
        print()
        solnmatrix = []
        totalhappiness = 0
        for var in lp.variables():
            if (var.value() == 1):
                tempprof = str(var.name.split("_")[0])
                tempsub = str(var.name.split("_")[1]) + "-" + str(
                    var.name.split("_")[2]) + "-" + str(var.name.split("_")[3])
                temphappiness = self.happiness_fun(tempprof, tempsub)
                totalhappiness += temphappiness
                solnmatrix.append([tempprof,tempsub,temphappiness])
        finalsoln = sorted(solnmatrix, key=lambda x: int(x[0][4:]))
        table = tabulate(finalsoln, headers=["Professor", "Subject", "Happiness"], tablefmt="grid")
        
        if status == 1:
            with open("BinaryIntegerProgramOutput.txt", 'w') as file:
                file.write(table)
                file.write( "----------Total Happiness = " + str(totalhappiness))
        elif status != 1:     
            with open("BinaryIntegerProgramOutput.txt", 'w') as file:
                file.write("CRASH! This Problem is not feasible and the program crashes. But assignment has been done to the best of the program's ability \n")
                file.write(table)
                file.write( "----------Total Happiness = " + str(totalhappiness))   





obj1 = Distribution_with_LP
obj1()
