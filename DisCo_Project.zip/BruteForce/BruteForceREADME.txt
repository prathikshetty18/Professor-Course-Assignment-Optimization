This is the README file for the Brute Force Method
NOTE**: This is not a big part of the Project but simply just to show our initial thought process

Components:
1. BruteForceInput.json
    This is a JSON(JavaScript Object Notation File) that serves as input for the BruteForce.py Program
    It consists of 3 Subjects and 3 Professors(Here the subjects are not divided into types and Professors only give one preference list)


2. BruteForce.py
    The code starts by importing the necessary libraries:
    json: For reading JSON data from a file
    itertools: For generating permutations
    numpy: For numerical operations
    tabulate: For creating tabular data representations

Procedure:
    The code starts by including 2 copies of every subject to represent 0.5 of a subject being assigned to a Professor
    Similarly Professors are included X times, where X is 2*(No of units they are willing to take)
    NOTE:(X can take the value 0.5, 1, 1.5)
    Then all Permutations of the subject list and Professor list are made and assignments are made
    A Matrix is the made with it's rows corresponding to the permutation of Subjects and similarly,
    columns corresponding to a permutation of Professors and all it's values are calculated using the happiness_value function
    The highest matrix values and the assignments that correspond to them are taken and printed.

Merits of Method:
    It is simple to come up with and easy to code.

Demerits of Method:
    It has exponential time Complexity
    It is difficult to introduce any constraints without Further WORSENING time Complexity
    It is not sustainable for more than 5 subjects and 5 professors due to BAD Space Complexity as well

How to Run:
    Place BruteForceInput.json and BruteForce.py in the same Directory
    Run BruteForce.py
    Output will be available on Terminal

NOTE**:
happiness_value(): This function takes a fixed subject and a professor and returns (length of the subject list) - (index of the fixed subject in the professors priority list).
                   Thereby giving a higher happiness value for a subject whose preference is more
                   This will also make the method standard for one set of professors and subjects
