import random
import json

Subjects =  ["FDCDC1-Y1-S1", "FDCDC2-Y1-S1", "FDCDC3-Y1-S1",
             "HDCDC1-Y1-S1", "HDCDC2-Y1-S1",

             "FDCDC1-Y2-S1", "FDCDC2-Y2-S1", "FDCDC3-Y2-S1", "FDCDC4-Y2-S1",
             "FDE1-Y2-S1", "FDE2-Y2-S1", "FDE3-Y2-S1", "FDE4-Y2-S1", "FDE5-Y2-S1", "FDE6-Y2-S1",
             "HDCDC1-Y2-S1", "HDCDC2-Y2-S1",
             "HDE1-Y2-S1", "HDE2-Y2-S1", "HDE3-Y2-S1", "HDE4-Y2-S1",

             "FDCDC1-Y3-S1", "FDCDC2-Y3-S1", "FDCDC3-Y3-S1", "FDCDC4-Y3-S1",
             "FDE1-Y3-S1", "FDE2-Y3-S1", "FDE3-Y3-S1", "FDE4-Y3-S1", "FDE5-Y3-S1", "FDE6-Y3-S1",
             "HDCDC1-Y3-S1", "HDCDC2-Y3-S1",
             "HDE1-Y3-S1", "HDE2-Y3-S1", "HDE3-Y3-S1", "HDE4-Y3-S1",

             "FDE1-Y4-S1", "FDE2-Y4-S1", "FDE3-Y4-S1", "FDE4-Y4-S1", "FDE5-Y4-S1", "FDE6-Y4-S1",
             "HDE1-Y4-S1", "HDE2-Y4-S1", "HDE3-Y4-S1", "HDE4-Y4-S1"]

FDCDC_Subjects = []
HDCDC_Subjects = []
FDE_Subjects = []
HDE_Subjects = []
for subject in Subjects:
    temp = subject.split("-")
    if("FDCDC" in temp[0]):
        FDCDC_Subjects.append(subject)
    elif ("HDCDC" in temp[0]):
        HDCDC_Subjects.append(subject)
    elif ("FDE" in temp[0]):
        FDE_Subjects.append(subject)
    elif ("HDE" in temp[0]):
        HDE_Subjects.append(subject)

Professors = {}
X_values = []
while(sum(X_values) <= (91-random.randint(0,len(FDE_Subjects)+len(HDE_Subjects)-2))):
    X_values.append(random.randint(1,3))

if(sum(X_values)%2 == 1):
    if(X_values[-1] ==1):
        X_values[-1] = 2
    elif (X_values[-1] == 2):
        X_values[-1] = 3
    elif (X_values[-1] == 3):
        X_values[-1] = 2

for i in range(len(X_values)):
    sampleFDCDC = random.sample(range(0,len(FDCDC_Subjects)),4)
    tempFDCDC = [FDCDC_Subjects[sampleFDCDC[0]],FDCDC_Subjects[sampleFDCDC[1]],FDCDC_Subjects[sampleFDCDC[2]],FDCDC_Subjects[sampleFDCDC[3]]]
    sampleFDE = random.sample(range(0, len(FDE_Subjects)), 4)
    tempFDE = [FDE_Subjects[sampleFDE[0]], FDE_Subjects[sampleFDE[1]], FDE_Subjects[sampleFDE[2]],FDE_Subjects[sampleFDE[3]]]

    sampleHDCDC = random.sample(range(0, len(HDCDC_Subjects)), 2)
    tempHDCDC = [HDCDC_Subjects[sampleHDCDC[0]], HDCDC_Subjects[sampleHDCDC[1]]]
    sampleHDE = random.sample(range(0, len(HDE_Subjects)), 2)
    tempHDE = [HDE_Subjects[sampleHDE[0]], HDE_Subjects[sampleHDE[1]]]
    Professors["Prof"+str(i)] = {"X":X_values[i],"PL-FDCDC":tempFDCDC,"PL-HDCDC":tempHDCDC,"PL-FDE":tempFDE,"PL-HDE":tempHDE}

Data = {}
Data["Subjects"] = Subjects
Data["Professors"] = Professors
print(X_values)
print(sum(X_values))

with open("randominput.json", 'w') as json_file:
    json.dump(Data, json_file, indent=3)
